package com.example.fredbrume.popularmovies.util;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

/**
 * Created by fredbrume on 7/19/17.
 */

public class MovieDBjsonUtils {


    public static String[] getMoviePosterStringFromJson(Context context, String posterUrlString) throws JSONException
    {
        String[] parsedPosterData =null;

        JSONObject posterJsonObject=new JSONObject(posterUrlString);

        JSONArray movieDetailsArray = posterJsonObject.getJSONArray("results");

        if(movieDetailsArray !=null)
        {
            parsedPosterData =new String[movieDetailsArray.length()];

            for(int i=0; i < movieDetailsArray.length(); ++i)
            {
                JSONObject posterObject = movieDetailsArray.getJSONObject(i);

                parsedPosterData[i]= (String) posterObject.get("poster_path");

            }
        }

        return parsedPosterData;
    }
}

package com.example.fredbrume.popularmovies;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.fredbrume.popularmovies.Adapter.PostAdapter;
import com.example.fredbrume.popularmovies.util.MovieDBjsonUtils;
import com.example.fredbrume.popularmovies.util.NetworkUtils;

import org.json.JSONException;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements PostAdapter.PosterAdapterOnClickHandler {

    private PostAdapter mAdapter;
    private final int gridColumns=2;
    private RecyclerView mPosterList;
    private GridLayoutManager layoutManager;
    private static String sortType="popular";
    private ProgressBar mLoadingIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mPosterList = (RecyclerView) findViewById(R.id.rv_posters);
        mLoadingIndicator= (ProgressBar) findViewById(R.id.pb_loading_indicator);

        layoutManager = new GridLayoutManager(this,gridColumns);
        mPosterList.setLayoutManager(layoutManager);

        mPosterList.setHasFixedSize(true);

        mAdapter = new PostAdapter(this);

        /* Setting the adapter attaches it to the RecyclerView in our layout. */
        mPosterList.setAdapter(mAdapter);

        loadPosterData();
    }

    private void loadPosterData()
    {
        showPosterView();

        URL sortUrl=NetworkUtils.buildUrl(sortType);
        new FetchPosterTask().execute(sortUrl);
    }

    private void showPosterView() {
        mPosterList.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(String poster) {

    }

    class FetchPosterTask extends AsyncTask<URL,Void,String[]>
    {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mLoadingIndicator.setVisibility(View.VISIBLE);
        }

        @Override
        protected String[] doInBackground(URL... params) {

            URL url=params[0];

            String[] simpleJsonPosterData =null;

            try {
                String jsonPosterResponse= NetworkUtils.getResponseFromHttpUrl(url);

                simpleJsonPosterData = MovieDBjsonUtils
                        .getMoviePosterStringFromJson(MainActivity.this, jsonPosterResponse);

                return simpleJsonPosterData;

            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }

            return null;
        }


        @Override
        protected void onPostExecute(String[] s) {

            mLoadingIndicator.setVisibility(View.INVISIBLE);
            if( s !=null)
            {
                showPosterView();
                mAdapter.setPosterData(s);
            }else
            {
                Toast.makeText(MainActivity.this, "Error: Unable to connect to server", Toast.LENGTH_SHORT).show();
            }
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId())
        {
            case R.id.action_popular:

                sortType = "popular";
                loadPosterData();
                break;

            case R.id.action_top_rated:

                sortType ="top_rated";
                loadPosterData();

                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.settings, menu);

        return true;
    }
}

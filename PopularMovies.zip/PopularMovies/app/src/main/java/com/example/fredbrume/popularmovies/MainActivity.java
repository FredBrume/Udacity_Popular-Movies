package com.example.fredbrume.popularmovies;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.fredbrume.popularmovies.Adapter.MainPageAdapter;

public class MainActivity extends AppCompatActivity {

    private static final int NUM_LIST_ITEMS = 100;
    private MainPageAdapter mAdapter;
    private RecyclerView mPosterList;
    private LinearLayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mPosterList = (RecyclerView) findViewById(R.id.rv_posters);

        layoutManager = new LinearLayoutManager(this);
        mPosterList.setLayoutManager(layoutManager);

        mPosterList.setHasFixedSize(true);

        mAdapter = new MainPageAdapter(getBaseContext(),NUM_LIST_ITEMS);

        mPosterList.setAdapter(mAdapter);
    }
}

package com.example.fredbrume.popularmovies.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.fredbrume.popularmovies.R;
import com.squareup.picasso.Picasso;

/**
 * Created by fredbrume on 7/18/17.
 */

public class MainPageAdapter extends RecyclerView.Adapter<MainPageAdapter.PosterViewHolder> {


    private static final String TAG = MainPageAdapter.class.getSimpleName();

    private Context context;

    private int mNumberItems;

    public MainPageAdapter(Context context, int numberOfItems) {

        mNumberItems = numberOfItems;
        this.context = context;
    }

    @Override
    public PosterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        Context context = parent.getContext();
        int layoutIdForListItem = R.layout.poster_list_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        boolean shouldAttachToParentImmediately = false;

        View view = inflater.inflate(layoutIdForListItem, parent, shouldAttachToParentImmediately);
        PosterViewHolder viewHolder = new PosterViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(PosterViewHolder holder, int position) {

        Log.d(TAG, "#" + position);
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return mNumberItems;
    }

    class PosterViewHolder extends RecyclerView.ViewHolder {

        ImageView listItemPosteriew;

        public PosterViewHolder(View itemView) {
            super(itemView);

            listItemPosteriew = (ImageView) itemView.findViewById(R.id.tv_item_poster);
        }

        void bind(int listIndex) {

            System.out.println(listIndex);

            Picasso.with(context).load("http://i.imgur.com/DvpvklR.png").into(listItemPosteriew);
        }

    }
}

package com.example.fredbrume.popularmovies.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.fredbrume.popularmovies.R;
import com.squareup.picasso.Picasso;

/**
 * Created by fredbrume on 7/18/17.
 */

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PosterViewHolder> {


    private static final String TAG = PostAdapter.class.getSimpleName();

    private Context context;
    
    private final String poster_base_path = "http://image.tmdb.org/t/p/original/";

    private static String[] mPosterData;

    private final PosterAdapterOnClickHandler mClickHandler;



    public PostAdapter(PosterAdapterOnClickHandler clickHandler) {

        mClickHandler = clickHandler;

    }

    @Override
    public PosterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        context = parent.getContext();
        int layoutIdForListItem = R.layout.poster_list_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        boolean shouldAttachToParentImmediately = false;

        View view = inflater.inflate(layoutIdForListItem, parent, shouldAttachToParentImmediately);

        return new PosterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PosterViewHolder holder, int position) {

        String poster=mPosterData[position];

        System.out.println("Poster: " + poster);

        Picasso.with(context).load(poster_base_path + poster).into(holder.listItemPosteriew);
    }

    @Override
    public int getItemCount() {

        if (null == mPosterData) return 0;
        return mPosterData.length;
    }

    public void setPosterData(String[] posterrData) {


        mPosterData = posterrData;
        notifyDataSetChanged();
    }

    public interface PosterAdapterOnClickHandler {

        void onClick(String poster);

    }

    public class PosterViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        ImageView listItemPosteriew;

        public PosterViewHolder(View itemView) {
            super(itemView);

            itemView.setOnClickListener(this);

            listItemPosteriew = (ImageView) itemView.findViewById(R.id.tv_item_poster);
        }

        @Override
        public void onClick(View v) {

            int adapterPosition = getAdapterPosition();
            String weatherForDay = mPosterData[adapterPosition];
            mClickHandler.onClick(weatherForDay);

        }
    }
}
